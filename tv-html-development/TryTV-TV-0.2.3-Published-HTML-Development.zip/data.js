'use strict';
const BASE='https://raw.githubusercontent.com/iiXDreemB52/TryTV-Downloads/refs/heads/main/trytv/';
function ownedURL(url,source){try{const a=new URL(url).hostname,b=new URL(source).hostname,aliases=['web5.topcinema.fan','web6.topcinema.fan','web.topcinema.io'];return a===b||(aliases.includes(a)&&aliases.includes(b))}catch{return false}}
const safeURL=(v,base)=>{try{const u=new URL(String(v||''),base);return u.protocol==='https:'&&!u.username&&!u.password?u.href:''}catch{return ''}};
async function network(url,options={}){
 if(!safeURL(url))throw Error('رابط غير صالح');
 const qs=new URLSearchParams({u:url,m:options.method||'GET',h:JSON.stringify(options.headers||{}),b:options.body||''});
 const r=await fetch('/api?'+qs),data=await r.json();
 if(data.error||!data.status)throw Error('تعذر الاتصال بالمصدر. تحقق من الإنترنت ثم أعد المحاولة.');
 if(data.status<200||data.status>=300)throw Error('المصدر غير متاح حاليًا (HTTP '+data.status+')');return data;
}
async function jsonAt(url){return JSON.parse((await network(url)).body)}
async function digest(text){const h=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));return Array.from(new Uint8Array(h),b=>b.toString(16).padStart(2,'0')).join('')}
function canonicalSources(raw){let i=0;while(i<raw.length){if(raw[i]!==String.fromCharCode(34)){i++;continue}const start=i++;while(i<raw.length){if(raw[i]==='\\'){i+=2;continue}if(raw[i++]===String.fromCharCode(34))break}const token=raw.slice(start,i);let j=i;while(/\s/.test(raw[j]||''))j++;if(JSON.parse(token)!=='sources'||raw[j]!==':')continue;j++;while(/\s/.test(raw[j]||''))j++;if(raw[j]!=='[')continue;let level=0,inString=false,escaped=false,out='';for(;j<raw.length;j++){const ch=raw[j];if(inString){out+=ch;if(escaped)escaped=false;else if(ch==='\\')escaped=true;else if(ch===String.fromCharCode(34))inString=false;continue}if(ch===String.fromCharCode(34)){inString=true;out+=ch;continue}if(/\s/.test(ch))continue;out+=ch;if(ch==='['||ch==='{')level++;if(ch===']'||ch==='}')level--;if(!level)return out}}return ''}
async function checkedRegistry(x,canonical=''){if(x?.schema!==1||!Array.isArray(x.sources)||x.sources.length>200)throw Error('تعذر التحقق من اعتماد المصادر');const normal=JSON.stringify(x.sources);if(await digest(normal)!==x.revision){if(!canonical||JSON.stringify(JSON.parse(canonical))!==normal||await digest(canonical)!==x.revision)throw Error('تعذر التحقق من اعتماد المصادر')}Object.defineProperty(x,'_canonical',{value:canonical||normal,enumerable:false});return x}
async function registryAt(url){const raw=(await network(url)).body;return checkedRegistry(JSON.parse(raw),canonicalSources(raw))}
function hubFor(x){const t=String(x.contentType||'').toLowerCase();return /manhwa|manhua|manga|comics/.test(t)||x.mediaType==='manhwa'||x.mediaType==='manga'?'manhwa':/anime|cartoon|animation/.test(t)?'anime':/series|movies|movie/.test(t)||['movies','series'].includes(x.mediaType)?'movies':'anime'}
function isDubbed(x){return x.dubbed===true||/dubbed|مدبلج/.test(x.contentType+' '+x.title+' '+x.audioType)}
function idb(){return new Promise((resolve,reject)=>{const r=indexedDB.open('trytv-tv-central-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('data');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function cached(key,value){try{const db=await idb();return await new Promise((resolve,reject)=>{const tx=db.transaction('data',value===undefined?'readonly':'readwrite'),store=tx.objectStore('data'),r=value===undefined?store.get(key):store.put(value,key);let out;r.onsuccess=()=>out=r.result;tx.oncomplete=()=>{db.close();resolve(out)};tx.onerror=()=>{db.close();reject(tx.error)}})}catch{return null}}
// Same priority as TryTV Windows trytvCategoryRecentSort.
function trytvWindowsRecency(x){
 for(const raw of [x.latestEpisodeAt,x.lastEpisodeDate,x.sourcePublishedAt,x.publishedAt,x.date,x.indexedChangeAt,x.updatedAt]){
  if(!raw)continue;
  const stamp=typeof raw==='number'?(raw>1e12?raw:raw*1000):Date.parse(String(raw));
  if(Number.isFinite(stamp)&&stamp>0)return stamp;
 }
 return 0;
}
function trytvWindowsStatusRank(x){
 const value=String(x.releaseStatus||'').toLowerCase();
 return /ongoing|releasing|مستمر|يعرض|جاري/.test(value)?0:/complete|finished|ended|مكتمل|منتهي/.test(value)?2:1;
}
function trytvWindowsRecentSort(rows){
 return rows.slice().sort((a,b)=>
  trytvWindowsRecency(b)-trytvWindowsRecency(a)||
  trytvWindowsStatusRank(a)-trytvWindowsStatusRank(b)||
  (a.sourceUrl===b.sourceUrl&&Number(a.sourceListPosition)>0&&Number(b.sourceListPosition)>0?
   Number(a.sourceListPosition)-Number(b.sourceListPosition):0)||
  a._order-b._order);
}
const Data={registry:null,manifest:null,routeManifest:null,parts:[],rows:[],byKey:new Map(),routeCache:new Map(),syncing:null,online:false,error:'',loaded:0,total:0,lastCheck:0};
Data.rebuild=function(){const approved=new Map((this.registry?.sources||[]).filter(s=>s.enabled&&s.review?.passed===true&&safeURL(s.url)).map(s=>[s.url,{...s,excluded:new Set(s.hiddenWorks||[])}]));this.approved=approved;const seenURL=new Set(),seenNames=new Set(),rows=[],allRows=[];
 for(const part of this.parts||[])for(const raw of part||[]){const source=approved.get(raw.sourceUrl);if(!source||source.excluded.has(raw.seriesUrl)||!safeURL(raw.seriesUrl)||!raw.title||this.manifest?.sources?.[raw.sourceUrl]?.complete!==true)continue;
  let own;try{own=ownedURL(raw.seriesUrl,raw.sourceUrl)}catch{continue}if(!own)continue;
  const disneyCartoonSeries=/animezid[.]org[/]category[.]php[?]cat=disney-series/i.test(raw.sourceUrl||'');const kind=disneyCartoonSeries?'anime':hubFor(raw),name=String(raw.title).toLowerCase().replace(/[\u064B-\u065F\u0670]/g,'').replace(/\s+/g,' ').trim(),signature=kind+'|'+name+'|'+isDubbed(raw);if(seenURL.has(raw.seriesUrl))continue;
  seenURL.add(raw.seriesUrl);
  const work={...raw,contentType:disneyCartoonSeries?'cartoon_dubbed_candidate':raw.contentType,key:raw.seriesUrl,kind,dubbed:isDubbed(raw),sourceName:source.name||new URL(raw.sourceUrl).hostname,source,cover:safeURL(raw.cover),_order:allRows.length};
  allRows.push(work);
  if(seenNames.has(signature))continue;
  seenNames.add(signature);rows.push(work);
 }this.rows=trytvWindowsRecentSort(rows);
 this.hubs={anime:[],movies:[],manhwa:[]};
 for(const item of this.rows)(this.hubs[item.kind]||this.hubs.anime).push(item);
 this.fullRows=trytvWindowsRecentSort(allRows);
 this.sourceRows=new Map();
 for(const item of this.fullRows){
  if(!this.sourceRows.has(item.sourceUrl))this.sourceRows.set(item.sourceUrl,[]);
  this.sourceRows.get(item.sourceUrl).push(item);
 }
 this.byKey=new Map(allRows.map(x=>[x.key,x]));
 this.sourceVariants=new Map();
 for(const item of allRows){
  const label=String(item.title||'').toLocaleLowerCase().replace(/[ً-ٰٟـ]/g,'').replace(/[‎‏]/g,'').replace(/\s+/g,' ').trim();
  const media=/movies|movie|film/.test(String(item.contentType||''))||/movies|movie|film/.test(String(item.mediaType||''))?'movie':'series';
  const token=item.kind+'|'+Number(item.dubbed)+'|'+media+'|'+label;
  if(!this.sourceVariants.has(token))this.sourceVariants.set(token,[]);
  this.sourceVariants.get(token).push(item);
  item._sourceVariantToken=token;
 }
 this.alternativesFor=work=>(this.sourceVariants.get(work._sourceVariantToken)||[work])
  .filter(x=>!work.releaseYear||!x.releaseYear||Number(work.releaseYear)===Number(x.releaseYear))
  .filter((x,index,arr)=>arr.findIndex(y=>y.sourceUrl===x.sourceUrl)===index);};
Data.bootstrap=async function(){window.TryTVBoot?.set(22,'جاري تجهيز الصفحة الرئيسية...');let seed=await cached('snapshot');
 let bundleSelected=false;
 if(seed){
  try{
   const response=await fetch('seed-meta.json');
   if(response.ok){
    const meta=await response.json();
    const oldDate=Date.parse(seed.registry?.publishedAt||0);
    if((seed.manifest?.revision||0)<meta.workRevision ||
       (seed.routeManifest?.revision||0)<meta.routeRevision ||
       oldDate<Date.parse(meta.registryPublishedAt)){
      const file=await fetch('seed.json');seed=await file.json();bundleSelected=true;
    }
   }
  }catch(e){}
 }
 if(!seed){const r=await fetch('seed.json');seed=await r.json();bundleSelected=true}
 if(bundleSelected)setTimeout(()=>cached('snapshot',seed).catch(()=>{}),2500);this.registry=await checkedRegistry(seed.registry,seed.registryCanonical);this.manifest=seed.manifest;this.routeManifest=seed.routeManifest;this.parts=seed.parts;window.TryTVBoot?.set(70,'جارٍ تجهيز مكتبة الأعمال...');this.rebuild();window.TryTVBoot?.set(96,'اكتمل تجهيز المكتبة');this.onChanged?.();this.sync(true).catch(()=>{});};
Data.sync=function(force=false){if(this.syncing)return this.syncing;this.syncing=(async()=>{this.error='';try{
 const stamp=Math.floor(Date.now()/60000),reg=await registryAt(BASE+'approved-sources.json?t='+stamp);
 if(this.registry&&Date.parse(reg.publishedAt||0)<Date.parse(this.registry.publishedAt||0))throw Error('تأخر تحديث المصادر؛ أعد المحاولة قريبًا');
 const registryChanged=reg.revision!==this.registry?.revision;this.registry=reg;if(registryChanged){this.rebuild();this.onChanged?.()}
 const [manifest,routes]=await Promise.all([jsonAt(BASE+'work-maps/manifest.json?t='+stamp),jsonAt(BASE+'work-routes/manifest.json?t='+stamp)]);
 if(manifest?.schema!==1||!Number.isSafeInteger(manifest.revision)||!Array.isArray(manifest.shards)||manifest.shards.length>500||routes?.schema!==1||!Number.isSafeInteger(routes.revision)||!routes.index||!Array.isArray(routes.shards))throw Error('خرائط مدير المصادر غير مكتملة');
 if(this.manifest&&manifest.revision<this.manifest.revision)throw Error('تحديث الخرائط لم يكتمل على الخادم');
 if(!this.routeManifest||routes.revision>=this.routeManifest.revision){if(routes.revision!==this.routeManifest?.revision)this.routeCache.clear();this.routeManifest=routes}
 const changed=manifest.revision!==this.manifest?.revision;const newParts=[];this.loaded=0;this.total=manifest.shards.length;
 if(changed||!this.parts.length){let cursor=0;const workers=Array.from({length:5},async()=>{for(;;){const i=cursor++;if(i>=manifest.shards.length)return;const shard=manifest.shards[i];if(!/^shard-\d{4}\.json$/.test(shard.path)||!/^[a-f0-9]{64}$/.test(shard.sha256))throw Error('خريطة غير صالحة');const old=this.manifest?.shards?.findIndex(s=>s.path===shard.path&&s.sha256===shard.sha256);if(old>=0&&this.parts[old])newParts[i]=this.parts[old];else{const response=await network(BASE+'work-maps/'+shard.path+'?r='+manifest.revision);if(await digest(response.body)!==shard.sha256)throw Error('فشل التحقق من خريطة الأعمال');const data=JSON.parse(response.body);if(data.schema!==1||data.sourceUrl!==shard.sourceUrl||!Array.isArray(data.items)||data.items.length!==shard.count)throw Error('خريطة الأعمال غير مكتملة');newParts[i]=data.items;}this.loaded++;this.onProgress?.(this.loaded,this.total)}});await Promise.all(workers);this.parts=newParts;this.manifest=manifest;this.rebuild();}
 if(!this.routeManifest||routes.revision>=this.routeManifest.revision){if(routes.revision!==this.routeManifest?.revision)this.routeCache.clear();this.routeManifest=routes}
 this.online=true;this.lastCheck=Date.now();if(changed||registryChanged){await cached('snapshot',{registry:this.registry,registryCanonical:this.registry._canonical,manifest:this.manifest,routeManifest:this.routeManifest,parts:this.parts});this.onChanged?.()}
 }catch(e){this.online=false;this.error=e.message;throw e}finally{this.syncing=null;this.onStatus?.()}})();return this.syncing;};
Data.refreshRoutes=async function(){const routes=await jsonAt(BASE+'work-routes/manifest.json?t='+Date.now());if(routes?.schema!==1||!Number.isSafeInteger(routes.revision)||!routes.index||!Array.isArray(routes.shards)||routes.shards.length>1000||routes.revision<(this.routeManifest?.revision||0))throw Error('تحديث خرائط الحلقات لم يكتمل؛ أعد المحاولة');this.routeCache.clear();this.routeManifest=routes;return routes;};
Data.route=async function(work,retry=0){if(!this.approved.has(work.sourceUrl))throw Error('هذا المصدر لم يعد معتمدًا');const key=await digest(work.sourceUrl+'\n'+work.seriesUrl);const manifest=this.routeManifest;if(!manifest?.index)throw Error('خرائط الحلقات غير متاحة');const n=manifest.index[key];if(!Number.isSafeInteger(n)||!manifest.shards[n]){if(retry<1){await this.refreshRoutes();return this.route(work,1)}throw Error('لم تُنشر خريطة حلقات هذا العمل بعد')}const shard=manifest.shards[n];if(!/^route-\d{4}\.json$/.test(shard.path))throw Error('مسار الحلقات غير صالح');let rows=this.routeCache.get(shard.sha256);if(!rows){let body=await cached('route:'+shard.sha256);if(!body||await digest(body)!==shard.sha256){body=(await network(BASE+'work-routes/'+shard.path+'?r='+manifest.revision+'&sha='+shard.sha256)).body;if(await digest(body)!==shard.sha256){if(retry<1){await this.refreshRoutes();return this.route(work,1)}throw Error('فشل التحقق من خريطة الحلقات؛ أعد المحاولة بعد اكتمال النشر')}await cached('route:'+shard.sha256,body)}const d=JSON.parse(body);if(d.schema!==1||!Array.isArray(d.items)||d.items.length!==shard.count)throw Error('خريطة الحلقات غير مكتملة');rows=d.items;this.routeCache.set(shard.sha256,rows);if(this.routeCache.size>10)this.routeCache.delete(this.routeCache.keys().next().value)}const route=rows.find(x=>x.sourceUrl===work.sourceUrl&&x.workUrl===work.seriesUrl&&x.complete===true);if(!route?.entries?.length)throw Error('لا توجد حلقات منشورة لهذا العمل');const sourceHost=new URL(work.sourceUrl).hostname;const seen=new Set();return {...route,entries:route.entries.filter(e=>{try{const good=safeURL(e.link)&&ownedURL(e.link,work.sourceUrl)&&!seen.has(e.link);seen.add(e.link);return good}catch{return false}}).sort((a,b)=>(Number(a.season)||1)-(Number(b.season)||1)||(Number(a.number)||0)-(Number(b.number)||0))};};
