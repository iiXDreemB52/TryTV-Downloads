"use strict";
const TVDisplay={
 scale:Math.min(105,Math.max(85,Number(localStorage.getItem('tv-scale'))||100)),
 safe:0,
 apply(){const w=document.documentElement.clientWidth||innerWidth,h=innerHeight;const u=Math.min(w/1280,h/720)*this.scale/100;document.documentElement.style.fontSize=(16*u)+'px';document.documentElement.style.setProperty('--safe-x','0px');document.documentElement.style.setProperty('--safe-y','0px');},
 set(k,v){if(k==='scale')this.scale=v;else this.safe=v;localStorage.setItem('tv-'+k,v);this.apply();},
 info(){return `${innerWidth} × ${innerHeight} · DPR ${devicePixelRatio} · ${this.scale}%`}
};TVDisplay.apply();addEventListener('resize',()=>TVDisplay.apply());
