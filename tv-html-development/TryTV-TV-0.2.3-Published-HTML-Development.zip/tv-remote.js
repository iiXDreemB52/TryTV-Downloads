'use strict';
/* Smart Google-TV remote navigation on the unchanged TryTV Windows-like interface.
 * Access sidebar ONLY with Back; from sidebar Left enters the three main sections.
 * Up from content reaches sections; Down from sections reaches work cards.
 */
window.TVRemote=(()=>{
 const railSelector='.rail button[data-page]';
 const hubsSelector='.hubs button[data-hub]';
 const contentSelector='#main button,#main input,#main select,#main [tabindex="0"]';
 const $=(s,root=document)=>root.querySelector(s);
 const $$=(s,root=document)=>[...root.querySelectorAll(s)];
 const visible=el=>{
  if(!el||el.disabled||!el.isConnected)return false;
  const r=el.getBoundingClientRect();
  return r.width>0&&r.height>0&&getComputedStyle(el).visibility!=='hidden';
 };
 const list=s=>$$(s).filter(visible);
 const focus=el=>{
  if(!visible(el))return false;
  document.querySelectorAll('[data-remote-focus="true"]').forEach(x=>{if(x!==el)x.removeAttribute('data-remote-focus')});
  el.setAttribute('data-remote-focus','true');
  el.focus({preventScroll:true});
  if(el.matches('.poster-card')){el.scrollIntoView({block:'nearest',inline:'center',behavior:'instant'});const rect=(el.querySelector('.poster-art')||el).getBoundingClientRect();const y=window.scrollY+rect.top+rect.height/2-window.innerHeight*.5;window.scrollTo({top:Math.max(0,y),behavior:'instant'});requestAnimationFrame(()=>{if(document.activeElement!==el||!el.isConnected)return;const box=(el.querySelector('.poster-art')||el).getBoundingClientRect();window.scrollBy({top:(box.top+box.bottom)/2-innerHeight/2,behavior:'instant'});});}else if(el.closest('.home-hero')){window.scrollTo({top:0,behavior:'instant'});}else el.scrollIntoView({block:'nearest',inline:'nearest',behavior:'instant'});
  return true;
 };
 function homeMenu(){
  if($('#overlay')?.children.length){window.TryTV?.back?.();return true;}
  if(typeof S!=='undefined'&&S.page!=='home'){S.trail=[];go('home',S.hub);}window.scrollTo({top:0,behavior:'instant'});
  const home=$(railSelector+'[data-page="home"]');
  return focus(home);
 }
 function activeHub(){
  return $(hubsSelector+'[data-hub="'+((typeof S!=='undefined'?S.hub:'anime'))+'"]')||
   $('.hubs .hub.active')||list(hubsSelector)[0];
 }
 function hubFocus(){return focus(activeHub());}
 function firstWork(){
  const first=$$('#main .poster-card[data-item],#main button[data-episode],#main .poster-grid button[data-item]').find(visible);
  if(first)return focus(first);
  const controls=list(contentSelector);
  return focus(controls.find(x=>!x.matches('[data-act="back"]'))||controls[0]);
 }
 function closestDirectional(origin,candidates,key){
  const a=origin.getBoundingClientRect(),ax=a.left+a.width/2,ay=a.top+a.height/2;
  const horizontal=key==='ArrowLeft'||key==='ArrowRight';
  const positive=key==='ArrowRight'||key==='ArrowDown';
  let best=null,bestScore=Infinity;
  for(const target of candidates){
   if(target===origin)continue;
   const b=target.getBoundingClientRect(),dx=b.left+b.width/2-ax,dy=b.top+b.height/2-ay;
   const primary=horizontal?dx:dy,cross=horizontal?dy:dx;
   if((positive?primary:-primary)<8)continue;
   const overlapping=horizontal?(b.bottom>a.top&&b.top<a.bottom):(b.right>a.left&&b.left<a.right);
   const score=Math.abs(primary)+Math.abs(cross)*(overlapping?1.7:4);
   if(score<bestScore){bestScore=score;best=target;}
  }
  return best;
 }
 function keyName(e){
  if(e.key==='Left')return 'ArrowLeft';
  if(e.key==='Right')return 'ArrowRight';
  if(e.key==='Up')return 'ArrowUp';
  if(e.key==='Down')return 'ArrowDown';
  return e.key||({37:'ArrowLeft',38:'ArrowUp',39:'ArrowRight',40:'ArrowDown'}[e.keyCode]);
 }
 document.addEventListener('focusin',e=>{
  if(document.getElementById('overlay')?.children.length)return;
  if(e.target.matches(railSelector+','+hubsSelector+','+contentSelector)){
   document.querySelectorAll('[data-remote-focus="true"]').forEach(x=>{if(x!==e.target)x.removeAttribute('data-remote-focus')});
   e.target.setAttribute('data-remote-focus','true');
  }
 },true);
 document.addEventListener('keydown',e=>{
  const key=keyName(e);
  if($('#overlay')?.children.length)return; // dialogs, reader: keep modal's own navigation.
  const back=['Escape','BrowserBack','GoBack','Back','GamepadB'].includes(key)||e.keyCode===461;
  if(back){
   e.preventDefault();e.stopImmediatePropagation();if(typeof S!=='undefined'&&['details','source-search'].includes(S.page))window.TryTV?.back?.();else homeMenu();return;
  }
  if(key==='ContextMenu'||e.keyCode===82){
   e.preventDefault();e.stopImmediatePropagation();homeMenu();return;
  }
  if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(key))return;
  const active=document.activeElement;
  if(active?.matches('input,textarea')&&['ArrowLeft','ArrowRight'].includes(key)){
   // Native DPAD is delivered as a synthetic key; move the text caret explicitly.
   const at=Number(active.selectionStart)||0,step=key==='ArrowLeft'?-1:1;
   active.setSelectionRange(Math.max(0,Math.min(active.value.length,at+step)),
                            Math.max(0,Math.min(active.value.length,at+step)));
   e.preventDefault();e.stopImmediatePropagation();return;
  }
  const rail=list(railSelector),hubs=list(hubsSelector),content=list(contentSelector);
  if(!rail.length)return;
  let target=null;
  if(rail.includes(active)){
   if(key==='ArrowLeft'){if(hubs.length)target=activeHub();else{firstWork();return;}}
   else if(key==='ArrowDown'||key==='ArrowUp')target=closestDirectional(active,rail,key);
   else target=null; // Right may not jump into other app regions.
  } else if(!hubs.length){if(!content.includes(active))target=content[0]||rail[0];else target=closestDirectional(active,content,key);} else if(hubs.includes(active)){
   if(key==='ArrowDown'){
    e.preventDefault();e.stopImmediatePropagation();firstWork();return;
   }
   if(key==='ArrowUp')target=null;
   else {target=closestDirectional(active,hubs,key);if(key==='ArrowRight'&&!target)target=rail[0];}
  } else {
   if(!content.includes(active)){
    target=content[0]||rail[0]; // recover without jumping to the top departments
   }else {
    target=closestDirectional(active,content,key);
    if(key==='ArrowUp'&&!target)target=null;
   }
  }
  e.preventDefault();e.stopImmediatePropagation();
  if(target)focus(target);
 },true);
 // Changing tabs with OK should leave focus on the chosen tab, not jump to the rail.
 document.addEventListener('click',e=>{
  const hub=e.target.closest(hubsSelector);
  if(hub){
   const selected=hub.dataset.hub;
   requestAnimationFrame(()=>{
    if((typeof S!=='undefined'&&S.hub===selected))focus($(hubsSelector+'[data-hub="'+selected+'"]'));
   });
  }
 },false);
 // Android Activity.Result calls playbackResult when native Media3 is closed.
 const currentPlayback=window.TryTV?.playbackResult;
 if(typeof currentPlayback==='function'){
  window.TryTV.playbackResult=result=>{
   currentPlayback(result);
   if(!result?.next)requestAnimationFrame(()=>homeMenu());
  };
 }
 if(window.TryTV)window.TryTV.menu=()=>{if($('#overlay')?.children.length||['details','source-search'].includes(S.page)){window.TryTV.back();return;}if(S.page!=='home'){S.trail=[];go('home',S.hub);}window.scrollTo({top:0,behavior:'instant'});requestAnimationFrame(homeMenu);};
 return {homeMenu,hubFocus,firstWork};
})();
