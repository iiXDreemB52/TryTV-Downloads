'use strict';
// Windows startup layout; progress is tied to actual catalog phases.
window.TryTVBoot=(()=>{
 const root=document.getElementById('trytv-boot');
 const bar=document.getElementById('trytv-boot-fill');
 const pct=document.getElementById('trytv-boot-percent');
 const label=document.getElementById('trytv-boot-label');
 let value=0,ended=false;
 function set(n,description){
  if(ended)return;
  value=Math.max(value,Math.min(100,Math.round(Number(n)||0)));
  if(bar)bar.style.width=value+'%';
  if(pct)pct.textContent=value+'%';
  root?.querySelector('[role="progressbar"]')?.setAttribute('aria-valuenow',String(value));
  if(description&&label)label.textContent=description;
 }
 function finish(){
  if(ended)return;
  set(100,'اكتمل تجهيز البرنامج');
  ended=true;
  root?.classList.add('finished');
  root?.setAttribute('aria-hidden','true');
  setTimeout(()=>root?.remove(),400);
 }
 function fail(){
  if(ended)return;
  set(100,'تعذر تجهيز البيانات، يمكنك إعادة المحاولة');
  ended=true;
  root?.classList.add('finished');
  setTimeout(()=>root?.remove(),400);
 }
 set(5,'بدء تشغيل البرنامج...');
 return {set,finish,fail};
})();
