'use strict';
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const main=document.getElementById('main'),overlay=document.getElementById('overlay');
const titles={anime:'الانمي والكرتون',movies:'المسلسلات والأفلام',manhwa:'المانهوا والمانجا'};
function localRead(k,fallback){try{return JSON.parse(localStorage.getItem(k))??fallback}catch{return fallback}}
function localSave(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}
const S={page:'home',hub:'anime',query:'',filter:'الكل',source:'',limit:48,browseCountry:'الكل',item:null,route:null,season:1,trail:[],detailTicket:0,favorites:new Set(localRead('favorites',[])),history:localRead('history',[]),motion:localRead('motion',false),reader:null,readerReturn:null};
const navs=[['home','الرئيسية'],['search','البحث'],['favorite','المفضلة'],['history','السجل'],['sources','المصادر']];
document.getElementById('rail-links').innerHTML=navs.map(([id,label])=>`<button class="nav ${id==='home'?'active':''}" data-page="${id}" aria-label="${label}" title="${label}">${icon(id)}<span>${label}</span></button>`).join('');document.querySelectorAll('[data-icon]').forEach(x=>x.innerHTML=icon(x.dataset.icon));document.body.classList.toggle('reduce-motion',S.motion);
function notice(message){const el=document.querySelector('.toast');el.textContent=message;el.hidden=false;clearTimeout(notice.timer);notice.timer=setTimeout(()=>el.hidden=true,3300)}
function clock(){document.getElementById('clock').textContent=new Intl.DateTimeFormat('ar-SA',{hour:'2-digit',minute:'2-digit'}).format(new Date())}clock();setInterval(clock,60000);
function action(text,act,ico,cls=''){return `<button class="action ${cls}" data-act="${act}">${icon(ico)}<span>${esc(text)}</span></button>`}
function cleanTitle(x){return String(x.title||'').replace(/ مدبلج.*$/,'').replace(/^فيلم /,'').split(' | ')[0]}
const imageURL=(url,ref)=>url?'/image?u='+encodeURIComponent(url)+'&r='+encodeURIComponent(ref||url):'assets/logo.webp';
const historyFor=x=>S.history.find(h=>h.key===x.key);
function card(x,resume=false){const h=historyFor(x),progress=h?.duration?Math.min(100,h.position/h.duration*100):0;let meta=x.kind==='movies'&&x.releaseYear?String(x.releaseYear):x.sourceName;return `<button class="poster-card ${resume?'resume':''}" data-item="${esc(x.key)}" aria-label="${esc(x.title)}، فتح التفاصيل"><div class="poster-art"><img src="${esc(imageURL(x.cover,x.seriesUrl))}" alt="" loading="lazy">${x.kind!=='manhwa'?`<span class="dub">${x.dubbed?'مدبلجة':'مترجمة'}</span>`:''}${S.favorites.has(x.key)?`<span class="saved-mark">${icon('favorite')}</span>`:''}${resume&&progress>0?`<div class="progress"><b style="width:${progress}%"></b></div>`:''}</div><span class="poster-title">${esc(cleanTitle(x))}</span><span class="poster-sub">${esc(meta)}</span></button>`}
function shelf(label,rows,resume=false,hub=S.hub,filter='الكل'){if(!rows.length)return '';return `<section class="shelf"><div class="section-head"><h2>${label}</h2><button class="text-link" data-browse="${hub}" data-browse-filter="${esc(filter)}" aria-label="عرض كل أعمال ${esc(label)}">عرض الكل ${icon('back')}</button></div><div class="shelf-track">${rows.slice(0,resume?10:18).map(x=>card(x,resume)).join('')}</div></section>`}
function hubRows(){return Data.rows.filter(x=>x.kind===S.hub&&(!S.source||x.sourceUrl===S.source))}
function hero(x,details=false){if(!x)return '';const h=historyFor(x),featured=!details&&/آركين|arcane/i.test(x.title),score=Number(x.score)||0;return `<section class="hero ${details?'detail-hero':'home-hero'}"><div class="hero-bg ${featured?'featured':''}" data-bg="${details?'':esc(featured?'assets/backdrop.webp':imageURL(x.cover,x.seriesUrl))}"></div><div class="hero-copy"><div class="eyebrow">${esc(details?x.sourceName:titles[S.hub])}</div>${featured?'<div class="latin-title">ARCANE</div>':''}<h1>${esc(cleanTitle(x))}</h1><div class="metadata">${x.kind==='manhwa'?'<span>مانهوا ومانجا</span>':`<span class="dub">${x.dubbed?'مدبلجة':'مترجمة'}</span>`}${x.releaseYear?`<span>${esc(x.releaseYear)}</span>`:''}${x.kind!=='movies'&&x.releaseStatus?`<span>${esc(x.releaseStatus)}</span>`:''}${score>0?`<span class="score">★ ${score}</span>`:''}</div><p>${esc(x.description||'اختر '+(x.kind==='manhwa'?'الفصل وابدأ القراءة.':'الموسم والحلقة وابدأ المشاهدة.'))}</p><div class="actions">${(details?action(x.kind==='manhwa'?(h?'أكمل القراءة':'ابدأ القراءة'):(h?'أكمل المشاهدة':'شاهد الآن'),'play',x.kind==='manhwa'?'book':'play','primary'):'')}${details?action(S.favorites.has(x.key)?'في المفضلة':'أضف للمفضلة','save',S.favorites.has(x.key)?'check':'favorite',S.favorites.has(x.key)?'gold':'secondary'):action('التفاصيل','details','info','secondary')}</div></div></section>`}
function focusKey(el){if(!el)return '';if(el.id==='source-search')return 'source-search-input';if(el.id&&el.id.startsWith('tv-search-'))return 'tv-search:'+el.id;return el.dataset.source?'source:'+el.dataset.source:el.dataset.item?'item:'+el.dataset.item:el.dataset.act?'act:'+el.dataset.act:el.dataset.page?'page:'+el.dataset.page:el.dataset.filter?'filter:'+el.dataset.filter:''}
function restoreFocus(key){if(!key)return;if(key==='source-search-input'){document.getElementById('source-search')?.focus({preventScroll:true});return;}if(key.startsWith('tv-search:')){document.getElementById(key.slice(10))?.focus({preventScroll:true});return;}const [type,...rest]=key.split(':'),value=rest.join(':');const attrs={source:'source',item:'item',act:'act',page:'page',filter:'filter'};if(attrs[type])[...document.querySelectorAll('button')].find(x=>x.dataset[attrs[type]]===value)?.focus({preventScroll:true})}
function rerender(){const y=scrollY,key=focusKey(document.activeElement);render();window.scrollTo(0,y);restoreFocus(key)}
function remember(){S.trail.push({page:S.page,hub:S.hub,query:S.query,filter:S.filter,source:S.source,limit:S.limit,item:S.item,route:S.route,season:S.season,browseCountry:S.browseCountry,tvSearchKind:S.tvSearchKind,tvSearchType:S.tvSearchType,tvSearchCountry:S.tvSearchCountry,tvSearchGenre:S.tvSearchGenre,y:scrollY,focus:focusKey(document.activeElement)});if(S.trail.length>30)S.trail.shift()}
function go(page,hub){remember();S.page=page;S.limit=48;S.filter='الكل';S.browseCountry='الكل';S.source='';S.query='';if(hub)S.hub=hub;render();scrollTo(0,0);main.querySelector('input,button')?.focus({preventScroll:true})}
function filterMatch(x,filter){const type=String(x.contentType||'');if(filter==='الكل')return true;if(filter==='مدبلجة')return x.dubbed;if(filter==='مترجمة')return !x.dubbed;const rules={'أنمي ياباني':/anime_japanese/,'أنمي صيني':/anime_chinese/,'أنمي كوري':/anime_korean/,'أفلام الأنمي':/anime.*movie|movie.*anime/,'مسلسلات الكرتون':/cartoon/,'أفلام الكرتون':/animation.*movie/,'مانهوا كورية':/^manhwa/,'مانهوا صينية':/^manhua/,'مانجا يابانية':/^manga$/,'مسلسلات':/^series/,'أفلام':/^movies/};return rules[filter]?.test(type)||false}
function filters(){return S.hub==='anime'?['الكل','مدبلجة','مترجمة','أنمي ياباني','أنمي صيني','أنمي كوري','أفلام الأنمي','مسلسلات الكرتون','أفلام الكرتون']:S.hub==='movies'?['الكل','مدبلجة','مسلسلات','أفلام']:['الكل','مانهوا كورية','مانهوا صينية','مانجا يابانية']}
function pageGrid(rows){return rows.length?'<div class="poster-grid">'+rows.slice(0,S.limit).map(x=>card(x)).join('')+'</div>'+(rows.length>S.limit?'<div id="tv-more-sentinel" aria-hidden="true"></div>':''):'<div class="empty">لا توجد أعمال مطابقة حاليًا</div>'}
function loading(title='جاري جلب الحلقات…'){return `<div class="loading-panel"><img src="assets/logo.webp" alt="TryTV"><h2>${esc(title)}</h2></div>`}
function status(){const el=document.getElementById('sync-state');if(el)el.textContent=Data.online?'المصادر متصلة':'TryTV';}
function render(){document.body.dataset.page=S.page;document.querySelector('.top').hidden=!['home','browse'].includes(S.page);document.querySelectorAll('.nav').forEach(b=>{b.classList.toggle('active',b.dataset.page===S.page);b.setAttribute('aria-current',b.dataset.page===S.page?'page':'false')});document.querySelectorAll('.hub').forEach(b=>{b.classList.toggle('active',b.dataset.hub===S.hub);b.setAttribute('aria-pressed',b.dataset.hub===S.hub)});
 if(!Data.registry){main.innerHTML=loading('جاري تحميل مكتبة المصادر…');return}
 if(S.page==='home'){
  const list=hubRows();
  const recent=S.history.map(h=>Data.byKey.get(h.key)).filter(Boolean);
  main.innerHTML=TVRows.home(list,recent);
 }
 else if(S.page==='browse'){
  const list=hubRows(),selected=list.filter(x=>TVRows.isRow(S.filter)?TVRows.match(x,S.filter):filterMatch(x,S.filter));
  // Country facets belong only to the four translated series/movie categories.
  // Never show or preserve a country filter on "جميع الأعمال" or dubbed rows.
  const translatedCountryRows=new Set(['translated-asian-series','translated-foreign-series','translated-foreign-movies','translated-asian-movies']);
  const showCountryFilter=S.hub==='movies'&&translatedCountryRows.has(S.filter);
  const countries=showCountryFilter?TVRows.countriesFor(selected):[];
  if(!showCountryFilter||!countries.includes(S.browseCountry))S.browseCountry='الكل';
  const rows=selected.filter(x=>TVRows.hasCountry(x,S.browseCountry));
  const types=[['الكل','جميع الأعمال'],...(TVRows.groups[S.hub]||[]).flatMap(g=>g.rows)];
  const title=TVRows.isRow(S.filter)?TVRows.label(S.filter):(S.source?Data.approved.get(S.source)?.name:titles[S.hub]);
  const pills='<div class="pills">'+types.map(([id,label])=>'<button class="pill '+(S.filter===id?'active':'')+'" data-filter="'+id+'">'+esc(label)+'</button>').join('')+'</div>';
  const countryBar=S.hub==='movies'&&countries.length?'<div class="tv-country-filter"><h2>الدول المتوفرة في هذا النوع</h2><div class="pills">'+[['الكل','جميع الدول'],...countries.map(c=>[c,c])].map(([id,label])=>'<button class="pill '+(S.browseCountry===id?'active':'')+'" data-browse-country="'+esc(id)+'">'+esc(label)+'</button>').join('')+'</div></div>':'';
  main.innerHTML='<div class="main-page"><h1 class="page-title">'+esc(title)+'</h1><p class="page-caption">'+rows.length.toLocaleString('ar-SA')+' عمل</p>'+pills+countryBar+pageGrid(rows)+'</div>';
 }
 else if(S.page==='details'){const x=S.item;if(!x){go('home');return}const kind=x.kind==='manhwa'?'الفصل':'الحلقة',route=S.route,entries=route?.entries||[],seasons=[...new Set(entries.map(e=>Number(e.season)||1))].sort((a,b)=>a-b),lastSeason=Math.max(1,...seasons),lastNo=Math.max(0,...entries.filter(e=>(Number(e.season)||1)===lastSeason).map(e=>Number(e.number)||0));const variants=typeof Data.alternativesFor==='function'?Data.alternativesFor(x):[x];
 const sourceChoice='<section class="tv-detail-sources" aria-label="مصادر هذا العمل"><div class="tv-source-current">حاليًا بالمصدر <strong>'+esc(x.sourceName)+'</strong></div>'+
 (variants.length>1?'<p class="tv-source-hint">اختر مصدرًا آخر لمشاهدة نفس العمل أو قراءة فصوله</p><div class="tv-source-switch-list">'+variants.map(v=>'<button class="tv-source-switch'+(v.key===x.key?' selected':'')+'" data-detail-source="'+esc(v.key)+'" aria-pressed="'+(v.key===x.key)+'" '+(v.key===x.key?'aria-current="true"':'')+'>'+esc(v.sourceName)+'</button>').join('')+'</div>':'')+'</section>';
 main.innerHTML=hero(x,true)+sourceChoice+`<section class="shelf"><div class="section-head"><h2>${x.kind==='manhwa'?'الفصول':'المواسم والحلقات'}</h2></div>${route?.error?`<div class="empty error-msg">${esc(route.error)}<div class="bottom-actions">${action('أعد المحاولة','retry-detail','history')}</div></div>`:!route?loading():`<div class="info-line">${lastNo?`<span>آخر ${kind}: ${lastNo}${seasons.length>1?' · الموسم '+lastSeason:''}</span>`:''}<span>${entries.length.toLocaleString('ar-SA')} ${x.kind==='manhwa'?'فصل':'حلقة'}</span></div>${seasons.length>1?`<div class="pills">${seasons.map(n=>`<button class="pill ${n===S.season?'active':''}" data-season="${n}">الموسم ${n}</button>`).join('')}</div>`:''}<div class="shelf-track">${entries.map((e,i)=>({e,i})).filter(({e})=>(Number(e.season)||1)===S.season).map(({e,i})=>`<button class="episode ${historyFor(x)?.episodeUrl===e.link?'watched':''}" data-episode="${i}" aria-label="${esc(e.title||kind+' '+e.number)}"><span class="episode-num">${Number(e.number)||i+1}</span><span><strong>${kind} ${Number(e.number)||i+1}</strong><small>${esc(e.title||x.title)}</small></span></button>`).join('')}</div>`}</section>`}
 else if(S.page==='search'){
  main.innerHTML='<div class="main-page"><h1 class="page-title">البحث</h1><div class="tv-search-workspace">'+TVRows.searchOptions()+'<div class="tv-search-results-pane"><label class="searchbox">'+icon('search')+'<input id="search" aria-label="ابحث عن عمل" placeholder="اسم العمل…" value="'+esc(S.query)+'" autocomplete="off"></label><div id="search-results"></div></div></div></div>';
  searchResults();
 }
 else if(S.page==='favorite'||S.page==='history'){const fav=S.page==='favorite',rows=fav?Data.rows.filter(x=>S.favorites.has(x.key)):S.history.map(x=>Data.byKey.get(x.key)).filter(Boolean);main.innerHTML=`<div class="main-page"><h1 class="page-title">${fav?'المفضلة':'آخر أعمال شاهدتها'}</h1><p class="page-caption">${fav?'أعمالك المحفوظة على هذه الشاشة':'أحدث مشاهدة تظهر أولًا'}</p>${rows.length?pageGrid(rows):`<div class="empty">${fav?'أضف عملًا من صفحة التفاصيل':'سيظهر هنا سجل مشاهدتك'}</div>`}${!fav&&rows.length?`<div class="history-clear">${action('مسح سجل المشاهدة','clear-history','trash')}</div>`:''}</div>`}
 else if(S.page==='source-search'){
  const src=Data.approved.get(S.source);
  if(!src){main.innerHTML='<div class="main-page"><h1 class="page-title">المصدر غير متوفر</h1></div>';}
  else{
   const count=(Data.fullRows||Data.rows).filter(x=>x.sourceUrl===S.source).length;
   main.innerHTML='<div class="main-page tv-source-search-page"><div class="tv-source-search-header"><h1 class="page-title">'+esc(src.name)+'</h1><p class="page-caption">ابحث عن عمل داخل هذا المصدر فقط</p></div><label class="searchbox tv-source-searchbox">'+icon('search')+'<input id="source-search" type="search" aria-label="البحث في '+esc(src.name)+'" placeholder="اكتب اسم العمل للبحث داخل المصدر…" autocomplete="off" spellcheck="false" value="'+esc(S.query)+'"></label><div id="source-search-results" aria-live="polite"></div></div>';
   sourceSearchResults();
  }
 }
 else if(S.page==='sources'){
  main.innerHTML='<div class="main-page"><h1 class="page-title">المصادر المعتمدة</h1><p class="page-caption">مرتبطة بمدير مصادر TryTV · '+Data.approved.size+' مصدر</p><div class="actions">'+action('تحديث المصادر','sync','history','primary')+'</div><div class="source-grid">'+[...Data.approved.values()].map(src=>TVRows.sourceCard(src,(Data.fullRows||Data.rows).filter(x=>x.sourceUrl===src.url).length)).join('')+'</div><p class="source-note">تظهر المصادر المعتمدة من المدير وصورها ومحتوياتها.</p></div>';
 }
 else if(S.page==='settings'){main.innerHTML=`<div class="main-page"><h1 class="page-title">الإعدادات</h1>${TryTVThemes.choices()}<div class="panel"><h2>تحديث التطبيق</h2><p class="source-note">التحقق من إصدارات TryTV وتثبيتها من داخل التطبيق.</p>${action('التحقق من التحديثات','update','history','primary')}</div><div class="panel"><h2>المصادر والمزامنة</h2><div class="setting-row"><span>المصادر المعتمدة<small>${Data.approved.size} مصدر · ${Data.rows.length.toLocaleString('ar-SA')} عمل</small></span>${action('تحديث الآن','sync','history','primary')}</div><div class="setting-row"><span>الاتصال<small>${esc(Data.online?'تم الاتصال بمدير المصادر':Data.error||'جاري التحقق…')}</small></span><span class="sources-summary">${Data.online?'متصل':'البيانات المحفوظة'}</span></div><div class="setting-row"><span>تقليل الحركة</span><button class="toggle ${S.motion?'on':''}" role="switch" aria-checked="${S.motion}" aria-label="تقليل الحركة" data-act="motion"></button></div></div><div class="panel"><h2>البيانات الشخصية</h2><p class="source-note">المفضلة وسجل المشاهدة وموضع الحلقة محفوظة محليًا على الشاشة. مزامنة حساب Google غير مفعّلة في إصدار التلفزيون الحالي.</p></div><p class="page-caption">TryTV · Google TV · 0.2.3</p></div>`}
 for(const el of main.querySelectorAll('[data-bg]'))el.style.backgroundImage='url('+JSON.stringify(el.dataset.bg)+')';status();
}
function sourceSearchResults(){
 const el=document.getElementById('source-search-results');
 if(!el)return;
 const query=String(S.query||'').trim().toLocaleLowerCase();
 if(!query){el.innerHTML='<div class="tv-source-search-prompt">'+icon('search')+'<p>اكتب اسم العمل للبحث في هذا المصدر</p></div>';return;}
 // Exact source URL, not a shared website hostname. Every card belongs to the selected source.
 const rows=(Data.fullRows||Data.rows).filter(x=>x.sourceUrl===S.source&&String(x.title||'').toLocaleLowerCase().includes(query));
 el.innerHTML='<p class="page-caption">'+rows.length.toLocaleString('ar-SA')+' نتيجة من هذا المصدر</p>'+pageGrid(rows);
}
function searchResults(){
 const query=String(S.query||'').trim().toLowerCase();
 const rows=TVRows.searchFilter(Data.rows).filter(x=>!query||[x.title,x.sourceName,x.country,...(x.genres||[])].join(' ').toLowerCase().includes(query));
 const el=document.getElementById('search-results');
 if(el)el.innerHTML='<p class="page-caption">'+rows.length.toLocaleString('ar-SA')+' نتيجة</p>'+pageGrid(rows);
}
async function detail(x,keep=false){if(!x)return;if(!keep)remember();S.item=x;S.page='details';S.hub=x.kind;S.route=null;const ticket=++S.detailTicket;render();if(!keep)scrollTo(0,0);try{const route=await Data.route(x);if(ticket!==S.detailTicket||S.page!=='details'||S.item.key!==x.key)return;S.route=route;const h=historyFor(x),ep=route.entries.find(e=>e.link===h?.episodeUrl);S.season=Number(ep?.season)||Number(route.entries[0]?.season)||1;rerender();main.querySelector('[data-act="play"]')?.focus({preventScroll:true})}catch(e){if(ticket===S.detailTicket&&S.item?.key===x.key){S.route={error:e.message};rerender()}}}
let dialogReturn=null;function dialog(title,text,buttons=''){dialogReturn=document.activeElement;overlay.innerHTML=`<div class="dialog" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="dialog-panel"><h2>${esc(title)}</h2><p>${esc(text)}</p><div class="actions">${buttons}${action('رجوع','close','back','secondary')}</div></div></div>`;overlay.querySelector('button')?.focus()}
function closeDialog(){if(S.reader){localSave('reader:'+S.reader.url,{y:overlay.querySelector('.reader-layer')?.scrollTop||0});S.reader=null}overlay.innerHTML='';dialogReturn?.focus({preventScroll:true})}
function back(){if(overlay.children.length){closeDialog();return}++S.detailTicket;const prev=S.trail.pop();if(prev){Object.assign(S,{page:prev.page,hub:prev.hub,query:prev.query,filter:prev.filter,source:prev.source,limit:prev.limit,item:prev.item,route:prev.route,season:prev.season,browseCountry:prev.browseCountry,tvSearchKind:prev.tvSearchKind,tvSearchType:prev.tvSearchType,tvSearchCountry:prev.tvSearchCountry,tvSearchGenre:prev.tvSearchGenre});render();scrollTo(0,prev.y);restoreFocus(prev.focus);return}if(S.page!=='home'){go('home',S.hub);return}dialog('مغادرة TryTV','هل تريد إغلاق التطبيق؟',action('مغادرة','exit','back'))}
async function playEpisode(index){const x=S.item;if(!x)return;let route=S.route;if(!route?.entries?.length){try{route=await Data.route(x);S.route=route}catch(e){notice(e.message);return}}const h=historyFor(x);if(index===undefined){const found=route.entries.findIndex(e=>e.link===h?.episodeUrl);index=found>=0?found:0}const episode=route.entries[index];if(!episode){notice('وصلت إلى آخر '+(x.kind==='manhwa'?'فصل':'حلقة'));return}if(x.kind==='manhwa'){openReader(index);return}
 dialog('جاري تجهيز الحلقة…','جاري استخراج سيرفرات المشاهدة من المصدر.');const token=++playEpisode.token;try{const servers=await resolveServers(episode,x);if(token!==playEpisode.token||!overlay.children.length)return;if(!servers.length)throw Error('لم يوفر المصدر سيرفرًا متاحًا لهذه الحلقة. جرّب حلقة أخرى أو راجع حالة المصدر في مدير المصادر.');closeDialog();const payload={title:cleanTitle(x)+' · '+(episode.title||'الحلقة '+episode.number),workKey:x.key,episodeUrl:episode.link,episodeIndex:index,hasNext:index+1<route.entries.length,hasPrev:index>0,position:h?.episodeUrl===episode.link?h.position||0:0,servers,serverReliability:x.source.serverReliability||{},hiddenServers:[...(x.source.hiddenServers||[]),...(x.source.autoHiddenServers||[])]};if(window.TryTVNative?.openPlayer)window.TryTVNative.openPlayer(JSON.stringify(payload));else throw Error('المشغّل متاح داخل تطبيق التلفزيون');}catch(e){if(token===playEpisode.token)dialog('تعذر تجهيز المشاهدة',e.message,action('أعد المحاولة','retry-play','history'))}}
playEpisode.token=0;
async function openReader(index){const x=S.item,e=S.route?.entries?.[index];if(!e)return;dialog('جاري تحميل الفصل…',e.title||x.title);try{const pages=await chapterPages(e,x);if(!pages.length)throw Error('تعذر قراءة صفحات هذا الفصل من المصدر');S.reader={index,url:e.link};rememberHistory({workKey:x.key,episodeUrl:e.link,episodeIndex:index,hasNext:index+1<route.entries.length,position:0,duration:0});const y=localRead('reader:'+e.link,{y:0}).y;overlay.innerHTML=`<section class="reader-layer" role="dialog" aria-modal="true" aria-label="قارئ الفصول"><header class="reader-controls"><span class="reader-heading">${esc(e.title||x.title)}</span><div class="actions">${action('العودة إلى الفصول','close','back')}${action('السابق','chapter-prev','back')}${action('التالي','chapter-next','next')}${action('تكبير','zoom','search')}</div></header><div class="reader-pages">${pages.map((u,i)=>`<img src="/image?u=${encodeURIComponent(u)}&r=${encodeURIComponent(e.link)}" alt="الصفحة ${i+1}" loading="${i<2?'eager':'lazy'}">`).join('')}</div></section>`;overlay.querySelector('.reader-layer').scrollTop=y;overlay.querySelector('button').focus({preventScroll:true})}catch(err){dialog('تعذر تحميل الفصل',err.message)}}
function rememberHistory(r){const h={key:r.workKey,episodeUrl:r.episodeUrl,episodeIndex:r.episodeIndex,position:Number(r.position)||0,duration:Number(r.duration)||0,at:Date.now()};S.history=[h,...S.history.filter(x=>x.key!==h.key)].slice(0,10);localSave('history',S.history)}
window.TryTV={notice,back,menu:()=>document.querySelector('[data-page="home"]').focus(),playbackResult:r=>{rememberHistory(r);if(r.next&&S.item?.key===r.workKey)playEpisode((Number(r.episodeIndex)||0)+1);else if(r.previous&&S.item?.key===r.workKey)playEpisode(Math.max(0,(Number(r.episodeIndex)||0)-1));else rerender()}};
document.addEventListener('error',e=>{if(e.target.tagName==='IMG'&&!e.target.src.endsWith('logo.webp')){e.target.src='assets/logo.webp';e.target.style.objectFit='contain'}},true);
document.addEventListener('input',e=>{if(e.target.id==='search'){S.query=e.target.value;S.limit=48;clearTimeout(searchResults.timer);searchResults.timer=setTimeout(searchResults,160)}
 if(e.target.id==='source-search'){S.query=e.target.value;S.limit=48;clearTimeout(sourceSearchResults.timer);sourceSearchResults.timer=setTimeout(sourceSearchResults,130)}});
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.tvFeature!==undefined){return}if(b.hasAttribute('data-tv-search-reset')){S.tvSearchKind='الكل';S.tvSearchType='الكل';S.tvSearchCountry='الكل';S.tvSearchDub='الكل';S.tvSearchGenre='الكل';rerender();return}if(b.dataset.page){go(b.dataset.page);return}if(b.dataset.hub){go('browse',b.dataset.hub);return}if(b.dataset.browse){if(b.dataset.browse==='history'){go('history');return}const chosen=b.dataset.browseFilter||'الكل';go('browse',b.dataset.browse);S.filter=chosen;render();return}if(b.dataset.item){detail(Data.byKey.get(b.dataset.item));return}
 if(b.dataset.detailSource){
  const variant=Data.byKey.get(b.dataset.detailSource);
  if(variant&&S.page==='details'&&S.item?.key!==variant.key){
   detail(variant,true).then(()=>{if(S.page==='details'&&S.item?.key===variant.key){
    [...document.querySelectorAll('[data-detail-source]')].find(c=>c.dataset.detailSource===variant.key)?.focus({preventScroll:true});
   }});
  }
  return;
 }
 if(b.dataset.source){const s=Data.approved.get(b.dataset.source);if(!s)return;const first=Data.rows.find(x=>x.sourceUrl===s.url);go('source-search',first?.kind||S.hub);S.source=s.url;S.query='';render();document.getElementById('source-search')?.focus({preventScroll:true});return}if(b.dataset.browseCountry){S.browseCountry=b.dataset.browseCountry;S.limit=48;rerender();return}if(b.dataset.filter){S.filter=b.dataset.filter;S.browseCountry='الكل';S.limit=48;rerender();return}if(b.dataset.searchFilter){S.filter=b.dataset.searchFilter;S.limit=48;main.querySelectorAll('[data-search-filter]').forEach(n=>n.classList.toggle('active',n===b));searchResults();return}if(b.dataset.episode!==undefined){playEpisode(+b.dataset.episode);return}if(b.dataset.season){S.season=+b.dataset.season;rerender();return}if(b.dataset.themeOption){const t=TryTVThemes.use(b.dataset.themeOption);main.querySelectorAll("[data-theme-option]").forEach(el=>{const chosen=el.dataset.themeOption===t.id;el.classList.toggle("selected",chosen);el.setAttribute("aria-pressed",String(chosen));el.querySelector(".tv-theme-check").textContent=chosen?"✓":""});const label=document.getElementById("tv-theme-current-name");if(label)label.textContent=t.name;return}if(b.dataset.scale){TVDisplay.set('scale',+b.dataset.scale);rerender();return}if(b.dataset.safe){TVDisplay.set('safe',+b.dataset.safe);rerender();return}const a=b.dataset.act;
 if(a==='update'){window.TryTVNative?.checkUpdate?.()}else if(a==='display-reset'){TVDisplay.set('scale',100);TVDisplay.set('safe',3);rerender()}else if(a==='calibrate'){document.querySelector('.calibration')?.remove();const edge=document.createElement('div');edge.className='calibration';document.body.append(edge);notice('يجب أن تظهر الحدود الذهبية كاملة داخل الشاشة');setTimeout(()=>edge.remove(),8000)}else if(a==='details'){window.scrollTo(0,0);detail(S.item);}else if(a==='quickplay'){detail(S.item).then(()=>playEpisode())}else if(a==='play'||a==='retry-play')playEpisode();else if(a==='retry-detail')detail(S.item,true);else if(a==='save'){const key=S.item.key;S.favorites.has(key)?S.favorites.delete(key):S.favorites.add(key);localSave('favorites',[...S.favorites]);rerender();notice(S.favorites.has(key)?'أُضيف إلى المفضلة':'أُزيل من المفضلة')}else if(a==='back')back();else if(a==='close'){++playEpisode.token;closeDialog()}else if(a==='exit')window.TryTVNative?.exit();else if(a==='more'){S.limit+=48;if(S.page==='search')searchResults();else rerender()}else if(a==='sync'){notice('جاري تحديث المصادر…');Data.sync(true).then(()=>{rerender();notice('تم تحديث المصادر')}).catch(e=>notice(e.message))}else if(a==='motion'){S.motion=!S.motion;localSave('motion',S.motion);document.body.classList.toggle('reduce-motion',S.motion);rerender()}else if(a==='clear-history'){dialog('مسح السجل','هل تريد مسح سجل المشاهدة على هذه الشاشة؟',action('مسح','confirm-clear','trash'))}else if(a==='confirm-clear'){S.history=[];localSave('history',[]);closeDialog();render()}else if(a==='chapter-next'||a==='chapter-prev'){const n=S.reader.index+(a==='chapter-next'?1:-1);if(n<0||n>=S.route.entries.length){notice('لا يوجد فصل آخر');return}closeDialog();openReader(n)}else if(a==='zoom'){overlay.querySelector('.reader-pages').classList.toggle('zoomed')}
});
function focusables(){const root=overlay.children.length?overlay:document;return [...root.querySelectorAll('button,input,select')].filter(x=>{const r=x.getBoundingClientRect();return !x.disabled&&r.width>0&&r.height>0})}
document.addEventListener('keydown',e=>{if(['Escape','BrowserBack','GoBack'].includes(e.key)||e.keyCode===461){e.preventDefault();back();return}const fs=focusables();if(e.key==='Tab'&&overlay.children.length){e.preventDefault();const i=fs.indexOf(document.activeElement);fs[(i+(e.shiftKey?-1:1)+fs.length)%fs.length]?.focus();return}if(!e.key.startsWith('Arrow'))return;if(e.target.tagName==='INPUT'&&['ArrowLeft','ArrowRight'].includes(e.key))return;if(S.reader&&['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();overlay.querySelector('.reader-layer').scrollBy({top:(e.key==='ArrowDown'?1:-1)*innerHeight*.65,behavior:S.motion?'auto':'smooth'});return}e.preventDefault();const a=document.activeElement;if(!fs.includes(a)){fs[0]?.focus();return}const r=a.getBoundingClientRect(),cx=r.x+r.width/2,cy=r.y+r.height/2,h=['ArrowLeft','ArrowRight'].includes(e.key),p=['ArrowRight','ArrowDown'].includes(e.key);let best=null,score=Infinity;for(const b of fs){if(b===a)continue;const q=b.getBoundingClientRect(),dx=q.x+q.width/2-cx,dy=q.y+q.height/2-cy,primary=h?dx:dy,cross=h?dy:dx;if((p?primary:-primary)<10)continue;const overlap=h?q.bottom>r.top&&q.top<r.bottom:q.right>r.left&&q.left<r.right;const value=Math.abs(primary)+Math.abs(cross)*(overlap?2:5);if(value<score){score=value;best=b}}if(best){best.focus({preventScroll:true});best.scrollIntoView({block:'nearest',inline:'nearest',behavior:S.motion?'auto':'smooth'})}});
Data.onChanged=()=>{if(S.item&&Data.byKey.has(S.item.key))S.item=Data.byKey.get(S.item.key);if(S.item&&!Data.byKey.has(S.item.key)&&S.page==='details'){S.page='home';S.route=null;S.trail=[]}if(!overlay.children.length&&S.page!=='details')rerender()};Data.onStatus=status;Data.onProgress=(n,total)=>{const e=document.getElementById('sync-state');e.textContent='المزامنة '+Math.round(n/total*100)+'٪'};
Data.bootstrap().then(()=>{window.TryTVBoot?.finish();window.TVRemote?.homeMenu()}).catch(e=>{main.innerHTML=`<div class="main-page"><h1 class="page-title">تعذر تحميل المكتبة</h1><p class="page-caption">${esc(e.message)}</p>${action('أعد المحاولة','sync','history')}</div>`;window.TryTVBoot?.fail()});setInterval(()=>Data.sync().catch(()=>{}),60000);

document.addEventListener('change',e=>{
 const field=e.target?.id,key={'tv-search-hub':'tvSearchKind','tv-search-type':'tvSearchType','tv-search-country':'tvSearchCountry','tv-search-dub':'tvSearchDub','tv-search-genre':'tvSearchGenre'}[field];
 if(!key)return;S[key]=e.target.value;
 if(key==='tvSearchKind'){S.tvSearchType='الكل';S.tvSearchCountry='الكل';S.tvSearchGenre='الكل'}if(key==='tvSearchType'){S.tvSearchCountry='الكل';S.tvSearchGenre='الكل'}
 rerender();
});

(function(){
 let observer;
 function watch(){
  if(observer)observer.disconnect();
  const el=document.getElementById('tv-more-sentinel');
  if(!el)return;
  observer=new IntersectionObserver(entries=>{
   if(!entries.some(x=>x.isIntersecting))return;
   observer.disconnect();S.limit+=36;rerender();
  },{rootMargin:'700px 0px'});observer.observe(el);
 }
 const parent=document.getElementById('main');
 new MutationObserver(()=>{
   clearTimeout(watch.t);watch.t=setTimeout(watch,35);
   if(S.page==='details'&&!document.querySelector('.tv-details-poster')&&S.item){
    const heroEl=document.querySelector('.detail-hero');
    if(heroEl){const p=document.createElement('div');p.className='tv-details-poster';const img=new Image();img.src=imageURL(S.item.cover,S.item.seriesUrl);img.alt='';p.append(img);heroEl.prepend(p);}
   }
 }).observe(parent,{childList:true});
 window.TryTV.refreshHome=()=>{
  if(!Data.registry)return;
  Data.rebuild();if(S.page==='home')rerender();
  if(!Data.syncing)Data.sync(true).catch(()=>{});
 };
})();
document.addEventListener('error',e=>{
 const img=e.target;if(img?.tagName!=='IMG')return;
 const url=img.currentSrc||img.src;if(url.includes('logo.webp'))return;
 const attempt=+(img.dataset.tvRetry||0);
 if(attempt===0&&/^https:\/\//.test(url)&&/manga|manhwa|kawaii|olympus|cdn/i.test(url)){
  img.dataset.tvRetry='1';img.src='https://wsrv.nl/?url='+encodeURIComponent(url)+'&w=420&output=webp';
 }else if(attempt<2){img.dataset.tvRetry='2';img.src='assets/logo.webp'}
},true);

/* Hero rotates only when home top is visible; never steals remote focus from the work grid. */
setInterval(()=>{
 if(S.page!=='home'||document.hidden||scrollY>100||overlay.children.length)return;
 if(document.activeElement?.closest('.hero button,.tv-search-sidebar'))return;
 const items=hubRows();
 if(items.length<2)return;
 S.tvFeatureIndex=((Number(S.tvFeatureIndex)||0)+1)%Math.min(8,items.length);
 rerender();
},15000);

/* TV APK update offer: non-blocking yellow strip, native Android normal installer. */
window.TryTVUpdate={
 offer(raw){
  let release;
  try{release=typeof raw==='string'?JSON.parse(raw):raw}catch{return}
  if(!release||Number(release.versionCode)<=0)return;
  let strip=document.getElementById('trytv-tv-update-strip');
  if(!strip){
   strip=document.createElement('aside');
   strip.id='trytv-tv-update-strip';
   strip.setAttribute('role','status');
   strip.setAttribute('aria-label','تحديث TryTV متاح');
   document.body.appendChild(strip);
  }
  strip.replaceChildren();
  const text=document.createElement('span');
  text.textContent='يتوفر تحديث TryTV للشاشة · '+String(release.versionName||'إصدار جديد');
  const btn=document.createElement('button');
  btn.type='button';btn.textContent='تنزيل وتثبيت التحديث';
  btn.setAttribute('data-tv-install-update','');
  btn.addEventListener('click',()=>window.TryTVNative?.downloadUpdate?.());
  const close=document.createElement('button');
  close.type='button';close.textContent='لاحقًا';close.setAttribute('aria-label','إخفاء شريط التحديث');
  close.addEventListener('click',()=>{strip.hidden=true});
  strip.append(text,btn,close);strip.hidden=false;
 }
};
