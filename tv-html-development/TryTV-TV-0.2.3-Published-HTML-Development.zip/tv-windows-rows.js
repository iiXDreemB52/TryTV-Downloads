'use strict';
/* TryTV Google TV 0.2.3: Windows content routes, titles and filter bindings. */
const TVRows=(()=>{
const groups={
movies:[
 {heading:'المترجمة',rows:[
  ['translated-asian-series','أحدث مسلسلات آسيوية'],
  ['translated-foreign-series','أحدث مسلسلات أجنبية'],
  ['translated-foreign-movies','أحدث الأفلام الأجنبية'],
  ['translated-asian-movies','أحدث الأفلام الآسيوية']]},
 {heading:'المدبلجة',rows:[
  ['dubbed-series','أحدث المسلسلات المدبلجة'],
  ['dubbed-movies','أحدث الأفلام المدبلجة']]}],
anime:[
 {heading:'المترجمة',rows:[
  ['translated-japanese-anime','أحدث الأنمي الياباني المترجم'],
  ['translated-chinese-anime','أحدث الأنمي الصيني المترجم'],
  ['translated-korean-anime','أحدث الأنمي الكوري المترجم'],
  ['translated-anime-movies','أحدث افلام الأنمي المترجم'],
  ['translated-cartoon-series','أحدث مسلسلات الكرتون المترجمة'],
  ['translated-cartoon-movies','أحدث افلام الكرتون المترجمة']]},
 {heading:'المدبلجة',rows:[
  ['dubbed-anime','أحدث الأنمي المدبلج'],
  ['dubbed-anime-movies','أحدث أفلام الأنمي المدبلجة'],
  ['dubbed-cartoon-series','أحدث مسلسلات الكرتون المدبلجة'],
  ['dubbed-cartoon-movies','أحدث افلام الكرتون المدبلجة']]}],
manhwa:[
 {heading:'',rows:[
  ['latest-korean-manhwa','أحدث المانهوا الكورية'],
  ['latest-chinese-manhwa','أحدث المانهوا الصينية'],
  ['latest-japanese-manga','أحدث المانجا اليابانية']]}]
};
const asia=/(asian|korean|chinese|japanese|korea|china|japan|turkey|thai|taiwan|آسيو|كوريا|اليابان|الصين|تايلاند|تايوان|تركيا)/i;
function match(x,id){
 const t=String(x.contentType||'').toLowerCase();
 const media=String(x.mediaType||'').toLowerCase();
 const country=String(x.country||'');
 const dub=Boolean(x.dubbed);
 const asian=/asian|_korean|_japanese|_chinese/.test(t)||(!/foreign/.test(t)&&asia.test(country));
 const mov=/movies|movie|film|فيلم/.test(t)||media==='movie'||media==='movies';
 const anime=/anime/.test(t)||media==='anime';
 const cartoon=/cartoon|animation/.test(t)||media==='cartoon';
 const manga=/^manga$/.test(t)||media==='manga';
 switch(id){
 case 'translated-asian-series':return x.kind==='movies'&&!mov&&!dub&&asian;
 case 'translated-foreign-series':return x.kind==='movies'&&!mov&&!dub&&!asian;
 case 'translated-foreign-movies':return x.kind==='movies'&&mov&&!dub&&!asian;
 case 'translated-asian-movies':return x.kind==='movies'&&mov&&!dub&&asian;
 case 'dubbed-series':return x.kind==='movies'&&!mov&&dub;
 case 'dubbed-movies':return x.kind==='movies'&&mov&&dub;
 case 'translated-japanese-anime':return x.kind==='anime'&&anime&&!cartoon&&!mov&&!dub&&!/chinese|korean/.test(t);
 case 'translated-chinese-anime':return x.kind==='anime'&&anime&&!mov&&!dub&&/chinese/.test(t);
 case 'translated-korean-anime':return x.kind==='anime'&&anime&&!mov&&!dub&&/korean/.test(t);
 case 'translated-anime-movies':return x.kind==='anime'&&(anime||/movies_anime/.test(t))&&mov&&!dub;
 case 'translated-cartoon-series':return x.kind==='anime'&&cartoon&&!mov&&!dub;
 case 'translated-cartoon-movies':return x.kind==='anime'&&cartoon&&mov&&!dub;
 case 'dubbed-anime':return x.kind==='anime'&&anime&&!cartoon&&!mov&&dub;
 case 'dubbed-anime-movies':return x.kind==='anime'&&anime&&mov&&dub;
 case 'dubbed-cartoon-series':return x.kind==='anime'&&cartoon&&!mov&&dub;
 case 'dubbed-cartoon-movies':return x.kind==='anime'&&cartoon&&mov&&dub;
 case 'latest-korean-manhwa':return x.kind==='manhwa'&&/^manhwa/.test(t);
 case 'latest-chinese-manhwa':return x.kind==='manhwa'&&/^manhua/.test(t);
 case 'latest-japanese-manga':return x.kind==='manhwa'&&manga;
 default:return false;
 }
}
function isRow(id){return Object.values(groups).some(sets=>sets.some(g=>g.rows.some(r=>r[0]===id)))}
function label(id){for(const sets of Object.values(groups))for(const g of sets)for(const r of g.rows)if(r[0]===id)return r[1];return id}
function thumb(x,i,selected){return '<button class="tv-hero-thumb'+(selected?' active':'')+'" data-tv-feature="'+i+'" aria-label="'+esc(x.title)+'" aria-pressed="'+(!!selected)+'"><img alt="" src="'+esc(imageURL(x.cover,x.seriesUrl))+'"></button>'}
function featuredHero(list){
 const i=Number(S.tvFeatureIndex||0)%list.length, x=list[i];S.item=x;
 const poster='<div class="tv-feature-poster"><img src="'+esc(imageURL(x.cover,x.seriesUrl))+'" alt=""></div>';
 const count=Math.min(5,list.length);const thumbnails='<div class="tv-hero-thumbs">'+Array.from({length:count},(_,n)=>{const step=n-Math.floor(count/2),j=(i+step+list.length)%list.length;return thumb(list[j],j,step===0)}).join('')+'</div>';
 return hero(x).replace('<div class="hero-copy">',poster+'<div class="hero-copy">').replace('</div></section>',thumbnails+'</div></section>');
}
function home(list,recent){
 if(!list.length)return '<div class="main-page"><div class="empty">لا توجد أعمال منشورة في هذا القسم بعد</div></div>';
 const pieces=[featuredHero(list)];
 const watched=recent.filter(x=>x.kind===S.hub);
 if(watched.length)pieces.push(shelf('آخر أعمال شاهدتها',watched,true,S.hub,'الكل'));
 for(const group of groups[S.hub]||[]){
  const shelves=group.rows.map(row=>{
   const filtered=list.filter(x=>match(x,row[0]));
   return filtered.length?shelf(row[1],filtered,false,S.hub,row[0]):'<section class="shelf tv-empty-row"><div class="section-head"><h2>'+row[1]+'</h2><button class="text-link" data-browse="'+S.hub+'" data-browse-filter="'+row[0]+'">عرض الكل</button></div><div class="empty tv-row-empty">لا توجد أعمال منشورة لهذا النوع حاليًا</div></section>';
  }).filter(Boolean);
  if(!shelves.length)continue;
  if(group.heading)pieces.push('<div class="tv-content-divider"><span></span><h2>'+group.heading+'</h2><span></span></div>');
  pieces.push(...shelves);
 }
 return pieces.join('');
}
function sourceCard(s,count){
 let host='';try{host=new URL(s.url).hostname}catch{};
 const logo=String(s.logoUrl||s.logo||s.iconUrl||s.image||s.imageUrl||'');
 const img=logo.startsWith('https://')?logo:'https://www.google.com/s2/favicons?domain='+encodeURIComponent(host)+'&sz=128';
 return '<button class="source-tile tv-source-card" data-source="'+esc(s.url)+'"><div class="tv-source-logo"><img alt="" loading="lazy" src="'+esc(img)+'"></div><strong>'+esc(s.name)+'</strong><span>'+esc(host)+'</span><span class="count">'+count.toLocaleString('ar-SA')+' عمل</span></button>';
}
function searchOptions(){
 const types=[['الكل','الكل'],['movies','المسلسلات والأفلام'],['anime','الأنمي والكرتون'],['manhwa','المانهوا والمانجا']];
 const countries=['الكل','اليابان','كوريا الجنوبية','الصين','تركيا','الولايات المتحدة','المملكة المتحدة'];
 const genres=['الكل','أكشن','دراما','كوميديا','رومانسي','مغامرات','خيال','غموض'];
 function selection(id,title,options,selected){return '<label class="tv-search-filter"><span>'+title+'</span><select id="'+id+'" class="tv-search-control">'+options.map(v=>'<option value="'+esc(v[0])+'"'+(v[0]===selected?' selected':'')+'>'+esc(v[1])+'</option>').join('')+'</select></label>'}
 const kind=S.tvSearchKind||'الكل',dub=S.tvSearchDub||'الكل',country=S.tvSearchCountry||'الكل',genre=S.tvSearchGenre||'الكل',type=S.tvSearchType||'الكل';
 const opts=groups[kind]||Object.values(groups).flat();
 return '<aside class="tv-search-sidebar"><h2>الأقسام والأنواع والدول والمدبلج والمترجم والتصنيفات</h2>'+
 selection('tv-search-hub','القسم',types,kind)+
 selection('tv-search-type','نوع المحتوى',[['الكل','الكل'],...opts.flatMap(g=>g.rows)],type)+
 selection('tv-search-country','الدولة',countries.map(v=>[v,v]),country)+
 selection('tv-search-dub','الصوت',[['الكل','الكل'],['مدبلجة','مدبلجة'],['مترجمة','مترجمة']],dub)+
 selection('tv-search-genre','التصنيفات',genres.map(v=>[v,v]),genre)+
 '<button data-tv-search-reset class="action tv-search-reset">إعادة ضبط الفلاتر</button></aside>';
}
function searchFilter(rows){
 return rows.filter(x=>(!S.tvSearchKind||S.tvSearchKind==='الكل'||x.kind===S.tvSearchKind)&&
 (!S.tvSearchType||S.tvSearchType==='الكل'||match(x,S.tvSearchType))&&
 (!S.tvSearchDub||S.tvSearchDub==='الكل'||(S.tvSearchDub==='مدبلجة'===x.dubbed))&&
 (!S.tvSearchCountry||S.tvSearchCountry==='الكل'||String(x.country||'').includes(S.tvSearchCountry))&&
 (!S.tvSearchGenre||S.tvSearchGenre==='الكل'||(x.genres||[]).some(g=>String(g).includes(S.tvSearchGenre))));
}
return {groups,match,isRow,label,home,sourceCard,searchOptions,searchFilter};
})();

/* TV 0.2.3 design-review refinement — build from real source metadata. */
(()=>{
 const translated=new Set(['translated-asian-series','translated-foreign-series','translated-foreign-movies','translated-asian-movies','translated-japanese-anime','translated-chinese-anime','translated-korean-anime','translated-anime-movies','translated-cartoon-series','translated-cartoon-movies']);
 const map={
  'translated-asian-series':'أحدث مسلسلات آسيوية المترجمة',
  'translated-foreign-series':'أحدث مسلسلات أجنبية المترجمة',
  'translated-foreign-movies':'أحدث الأفلام الأجنبية المترجمة',
  'translated-asian-movies':'أحدث الأفلام الآسيوية المترجمة'
 };
 const originals=TVRows.match;
 TVRows.groups.movies.forEach(g=>g.rows.forEach(r=>{if(map[r[0]])r[1]=map[r[0]];}));
 TVRows.groups.anime.forEach(g=>g.rows.forEach(r=>{if(r[0]==='translated-cartoon-series')r[1]='أحدث مسلسلات الكرتون المترجمة';}));
 const title=id=>{for(const x of Object.values(TVRows.groups))for(const g of x)for(const r of g.rows)if(r[0]===id)return r[1];return id;};
 TVRows.label=title;
 TVRows.match=(x,id)=>{
  const t=String(x.contentType||'').toLowerCase(),url=String(x.sourceUrl||'').toLowerCase();
  if(url.includes('animezid.org')&&url.includes('cat=disney-series')){
   if(id==='dubbed-cartoon-series')return Boolean(x.dubbed);
   if(id==='dubbed-series')return false;
  }
  if(id==='translated-cartoon-series')return x.kind==='anime'&&/cartoon/.test(t)&&!/movie/.test(t)&&!x.dubbed;
  return originals(x,id);
 };
 // Group headings intentionally removed; every translated/dubbed row names its type.
 TVRows.home=(list,recent)=>{
  if(!list.length)return '<div class="main-page"><div class="empty">لا توجد أعمال منشورة في هذا القسم بعد</div></div>';
  const start=Number(S.tvFeatureIndex||0)%Math.min(list.length,20);
  const current=list[start];S.item=current;
  const poster='<div class="tv-feature-poster"><img loading="eager" decoding="async" src="'+esc(imageURL(current.cover,current.seriesUrl))+'" alt=""></div>';
  const desc=hero(current).replace(/<button[^>]*data-act="quickplay"[\s\S]*?<\/button>/,'');
  const heroHtml=desc.replace('<div class="hero-copy">',poster+'<div class="hero-copy">')
   .replace('</div></section>','</div></section>');
  const candidates=list.slice(0,Math.min(8,list.length));
  const dots='<div class="tv-feature-filmstrip" aria-hidden="true">'+candidates.map((w,i)=>'<span class="'+(i===start?'current':'')+'"><img alt="" loading="lazy" src="'+esc(imageURL(w.cover,w.seriesUrl))+'"></span>').join('')+'</div>';
  const shelves=[];
  const seen=new Set();
  for(const group of TVRows.groups[S.hub]||[])for(const [id,label] of group.rows){
   if(seen.has(id))continue;seen.add(id);
   const selected=list.filter(x=>TVRows.match(x,id));
   shelves.push(selected.length?shelf(label,selected,false,S.hub,id):'<section class="shelf tv-empty-row"><div class="section-head"><h2>'+label+'</h2></div><div class="empty tv-row-empty">لا توجد أعمال متاحة في هذا النوع حاليًا</div></section>');
  }
  const watched=recent.filter(x=>x.kind===S.hub);
  return heroHtml+dots+(watched.length?shelf('آخر أعمال شاهدتها',watched,true,S.hub,'الكل'):'')+shelves.join('');
 };
 const niceUnique=(xs)=>[...new Set(xs.map(s=>String(s||'').trim()).filter(x=>x&&x!=='غير محدد'))].sort((a,b)=>a.localeCompare(b,'ar'));
 function contextRows(){
  const k=S.tvSearchKind||'الكل',t=S.tvSearchType||'الكل';
  return Data.rows.filter(x=>(k==='الكل'||x.kind===k)&&(t==='الكل'||TVRows.match(x,t)));
 }
 function options(id,label,arr,value){
  return '<label class="tv-search-filter"><span>'+label+'</span><select id="'+id+'" class="tv-search-control">'+arr.map(([v,t])=>'<option value="'+esc(v)+'"'+(value===v?' selected':'')+'>'+esc(t)+'</option>').join('')+'</select></label>';
 }
 TVRows.searchOptions=()=>{
  const hub=S.tvSearchKind||'الكل',kindOptions=[['الكل','جميع الأقسام'],['movies','المسلسلات والأفلام'],['anime','الأنمي والكرتون'],['manhwa','المانهوا والمانجا']];
  const entries=hub==='الكل'?Object.values(TVRows.groups).flat():TVRows.groups[hub]||[];
  const types=[['الكل','جميع الأنواع'],...entries.flatMap(g=>g.rows)];
  const ctx=contextRows();
  const countries=niceUnique(ctx.filter(x=>x.kind==='movies').map(x=>x.country));
  const genres=niceUnique(ctx.flatMap(x=>Array.isArray(x.genres)?x.genres:[]));
  return '<aside class="tv-search-sidebar"><h2>تخصيص البحث</h2><p class="tv-search-explanation">تظهر التصنيفات الموجودة فعليًا في الأعمال حسب القسم والنوع.</p>'+
  options('tv-search-hub','القسم',kindOptions,hub)+
  options('tv-search-type','نوع المحتوى',types,S.tvSearchType||'الكل')+
  (hub==='movies'?options('tv-search-country','الدولة',[['الكل','جميع الدول'],...countries.map(c=>[c,c])],S.tvSearchCountry||'الكل'):'')+
  options('tv-search-genre','التصنيفات',[['الكل','جميع التصنيفات'],...genres.map(g=>[g,g])],S.tvSearchGenre||'الكل')+
  '<button class="action tv-search-reset" data-tv-search-reset>مسح التخصيص</button></aside>';
 };
 TVRows.searchFilter=(rows)=>rows.filter(x=>
  (!S.tvSearchKind||S.tvSearchKind==='الكل'||x.kind===S.tvSearchKind)&&
  (!S.tvSearchType||S.tvSearchType==='الكل'||TVRows.match(x,S.tvSearchType))&&
  (!S.tvSearchCountry||S.tvSearchCountry==='الكل'||x.kind!=='movies'||x.country===S.tvSearchCountry)&&
  (!S.tvSearchGenre||S.tvSearchGenre==='الكل'||(x.genres||[]).some(g=>String(g).trim()===S.tvSearchGenre)));
 TVRows.countriesFor=(items)=>niceUnique(items.filter(x=>x.kind==='movies').map(x=>x.country));
})();

/* Normalize known source-spelling variants while keeping only countries actually present. */
(()=>{
 const canonical=['الولايات المتحدة الامريكية','الولايات المتحدة الأمريكية','كوريا الجنوبية','كوريا الشمالية','المملكة المتحدة','الصين','اليابان','تايلاند','تايوان','الفلبين','الفليبين','أندونيسيا','إندونيسيا','الهند','تركيا','فرنسا','ألمانيا','روسيا','إسبانيا','كندا','أستراليا'];
 const normalize=s=>String(s||'').trim().replace('الفليبين','الفلبين').replace('أندونيسيا','إندونيسيا').replace('الولايات المتحدة الأمريكية','الولايات المتحدة الامريكية');
 const tokens=s=>{
  const raw=normalize(s);if(!raw)return [];
  const found=canonical.map(normalize).filter(x=>raw.includes(x));
  return found.length?[...new Set(found)]:[raw];
 };
 TVRows.hasCountry=(work,country)=>country==='الكل'||tokens(work.country).includes(country);
 TVRows.countriesFor=works=>[...new Set(works.filter(x=>x.kind==='movies').flatMap(x=>tokens(x.country)))].sort((a,b)=>a.localeCompare(b,'ar'));
 const search=TVRows.searchOptions;
 TVRows.searchOptions=()=>search().replace(/<select id="tv-search-country"[\s\S]*?<\/select>/,()=>{
  const ctx=Data.rows.filter(x=>x.kind==='movies'&&(!S.tvSearchType||S.tvSearchType==='الكل'||TVRows.match(x,S.tvSearchType)));
  const names=TVRows.countriesFor(ctx);
  return '<select id="tv-search-country" class="tv-search-control"><option value="الكل">جميع الدول</option>'+names.map(name=>'<option value="'+esc(name)+'"'+(name===S.tvSearchCountry?' selected':'')+'>'+esc(name)+'</option>').join('')+'</select>';
 });
 TVRows.searchFilter=rows=>rows.filter(x=>
  (!S.tvSearchKind||S.tvSearchKind==='الكل'||x.kind===S.tvSearchKind)&&
  (!S.tvSearchType||S.tvSearchType==='الكل'||TVRows.match(x,S.tvSearchType))&&
  (!S.tvSearchCountry||S.tvSearchCountry==='الكل'||TVRows.hasCountry(x,S.tvSearchCountry))&&
  (!S.tvSearchGenre||S.tvSearchGenre==='الكل'||(x.genres||[]).some(g=>String(g).trim()===S.tvSearchGenre)));
})();
