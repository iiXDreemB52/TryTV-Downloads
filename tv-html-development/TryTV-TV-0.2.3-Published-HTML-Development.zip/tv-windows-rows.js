'use strict';
/* TryTV Google TV 0.2.3: Windows content routes, titles and filter bindings. */
const TVRows=(()=>{
const groups={
movies:[
 {heading:'المترجمة',rows:[
  ['translated-asian-series','أحدث مسلسلات آسيوية'],
  ['translated-foreign-series','أحدث مسلسلات أجنبية'],
  ['translated-foreign-movies','أحدث الأفلام الأجنبية'],
  ['translated-asian-movies','أحدث الأفلام الآسيوية']]},
 {heading:'المدبلجة',rows:[
  ['dubbed-series','أحدث المسلسلات المدبلجة'],
  ['dubbed-movies','أحدث الأفلام المدبلجة']]}],
anime:[
 {heading:'المترجمة',rows:[
  ['translated-japanese-anime','أحدث الأنمي الياباني المترجم'],
  ['translated-chinese-anime','أحدث الأنمي الصيني المترجم'],
  ['translated-korean-anime','أحدث الأنمي الكوري المترجم'],
  ['translated-anime-movies','أحدث افلام الأنمي المترجم'],
  ['translated-cartoon-series','أحدث مسلسلات الكرتون المترجمة'],
  ['translated-cartoon-movies','أحدث افلام الكرتون المترجمة']]},
 {heading:'المدبلجة',rows:[
  ['dubbed-anime','أحدث الأنمي المدبلج'],
  ['dubbed-anime-movies','أحدث أفلام الأنمي المدبلجة'],
  ['dubbed-cartoon-series','أحدث مسلسلات الكرتون المدبلجة'],
  ['dubbed-cartoon-movies','أحدث افلام الكرتون المدبلجة']]}],
manhwa:[
 {heading:'',rows:[
  ['latest-korean-manhwa','أحدث المانهوا الكورية'],
  ['latest-chinese-manhwa','أحدث المانهوا الصينية'],
  ['latest-japanese-manga','أحدث المانجا اليابانية']]}]
};
const asia=/(asian|korean|chinese|japanese|korea|china|japan|turkey|thai|taiwan|آسيو|كوريا|اليابان|الصين|تايلاند|تايوان|تركيا)/i;
function match(x,id){
 const t=String(x.contentType||'').toLowerCase();
 const media=String(x.mediaType||'').toLowerCase();
 const country=String(x.country||'');
 const dub=Boolean(x.dubbed);
 const asian=/asian|_korean|_japanese|_chinese/.test(t)||(!/foreign/.test(t)&&asia.test(country));
 const mov=/movies|movie|film|فيلم/.test(t)||media==='movie'||media==='movies';
 const anime=/anime/.test(t)||media==='anime';
 const cartoon=/cartoon|animation/.test(t)||media==='cartoon';
 const manga=/^manga$/.test(t)||media==='manga';
 switch(id){
 case 'translated-asian-series':return x.kind==='movies'&&!mov&&!dub&&asian;
 case 'translated-foreign-series':return x.kind==='movies'&&!mov&&!dub&&!asian;
 case 'translated-foreign-movies':return x.kind==='movies'&&mov&&!dub&&!asian;
 case 'translated-asian-movies':return x.kind==='movies'&&mov&&!dub&&asian;
 case 'dubbed-series':return x.kind==='movies'&&!mov&&dub;
 case 'dubbed-movies':return x.kind==='movies'&&mov&&dub;
 case 'translated-japanese-anime':return x.kind==='anime'&&anime&&!cartoon&&!mov&&!dub&&!/chinese|korean/.test(t);
 case 'translated-chinese-anime':return x.kind==='anime'&&anime&&!mov&&!dub&&/chinese/.test(t);
 case 'translated-korean-anime':return x.kind==='anime'&&anime&&!mov&&!dub&&/korean/.test(t);
 case 'translated-anime-movies':return x.kind==='anime'&&(anime||/movies_anime/.test(t))&&mov&&!dub;
 case 'translated-cartoon-series':return x.kind==='anime'&&cartoon&&!mov&&!dub;
 case 'translated-cartoon-movies':return x.kind==='anime'&&cartoon&&mov&&!dub;
 case 'dubbed-anime':return x.kind==='anime'&&anime&&!cartoon&&!mov&&dub;
 case 'dubbed-anime-movies':return x.kind==='anime'&&anime&&mov&&dub;
 case 'dubbed-cartoon-series':return x.kind==='anime'&&cartoon&&!mov&&dub;
 case 'dubbed-cartoon-movies':return x.kind==='anime'&&cartoon&&mov&&dub;
 case 'latest-korean-manhwa':return x.kind==='manhwa'&&/^manhwa/.test(t);
 case 'latest-chinese-manhwa':return x.kind==='manhwa'&&/^manhua/.test(t);
 case 'latest-japanese-manga':return x.kind==='manhwa'&&manga;
 default:return false;
 }
}
function isRow(id){return Object.values(groups).some(sets=>sets.some(g=>g.rows.some(r=>r[0]===id)))}
function label(id){for(const sets of Object.values(groups))for(const g of sets)for(const r of g.rows)if(r[0]===id)return r[1];return id}
function thumb(x,i,selected){return '<button class="tv-hero-thumb'+(selected?' active':'')+'" data-tv-feature="'+i+'" aria-label="'+esc(x.title)+'" aria-pressed="'+(!!selected)+'"><img alt="" src="'+esc(imageURL(x.cover,x.seriesUrl))+'"></button>'}
function featuredHero(list){
 const i=Number(S.tvFeatureIndex||0)%list.length, x=list[i];S.item=x;
 const poster='<div class="tv-feature-poster"><img src="'+esc(imageURL(x.cover,x.seriesUrl))+'" alt=""></div>';
 const count=Math.min(5,list.length);const thumbnails='<div class="tv-hero-thumbs">'+Array.from({length:count},(_,n)=>{const step=n-Math.floor(count/2),j=(i+step+list.length)%list.length;return thumb(list[j],j,step===0)}).join('')+'</div>';
 return hero(x).replace('<div class="hero-copy">',poster+'<div class="hero-copy">').replace('</div></section>',thumbnails+'</div></section>');
}
function home(list,recent){
 if(!list.length)return '<div class="main-page"><div class="empty">لا توجد أعمال منشورة في هذا القسم بعد</div></div>';
 const pieces=[featuredHero(list)];
 const watched=recent.filter(x=>x.kind===S.hub);
 if(watched.length)pieces.push(shelf('آخر أعمال شاهدتها',watched,true,S.hub,'الكل'));
 for(const group of groups[S.hub]||[]){
  const shelves=group.rows.map(row=>{
   const filtered=list.filter(x=>match(x,row[0]));
   return filtered.length?shelf(row[1],filtered,false,S.hub,row[0]):'<section class="shelf tv-empty-row"><div class="section-head"><h2>'+row[1]+'</h2><button class="text-link" data-browse="'+S.hub+'" data-browse-filter="'+row[0]+'">عرض الكل</button></div><div class="empty tv-row-empty">لا توجد أعمال منشورة لهذا النوع حاليًا</div></section>';
  }).filter(Boolean);
  if(!shelves.length)continue;
  if(group.heading)pieces.push('<div class="tv-content-divider"><span></span><h2>'+group.heading+'</h2><span></span></div>');
  pieces.push(...shelves);
 }
 return pieces.join('');
}
function sourceCard(s,count){
 let host='';try{host=new URL(s.url).hostname}catch{};
 const logo=String(s.logoUrl||s.logo||s.iconUrl||s.image||s.imageUrl||'');
 const img=logo.startsWith('https://')?logo:'https://www.google.com/s2/favicons?domain='+encodeURIComponent(host)+'&sz=128';
 return '<button class="source-tile tv-source-card" data-source="'+esc(s.url)+'"><div class="tv-source-logo"><img alt="" loading="lazy" src="'+esc(img)+'"></div><strong>'+esc(s.name)+'</strong><span>'+esc(host)+'</span><span class="count">'+count.toLocaleString('ar-SA')+' عمل</span></button>';
}
function searchOptions(){
 const types=[['الكل','الكل'],['movies','المسلسلات والأفلام'],['anime','الأنمي والكرتون'],['manhwa','المانهوا والمانجا']];
 const countries=['الكل','اليابان','كوريا الجنوبية','الصين','تركيا','الولايات المتحدة','المملكة المتحدة'];
 const genres=['الكل','أكشن','دراما','كوميديا','رومانسي','مغامرات','خيال','غموض'];
 function selection(id,title,options,selected){return '<label class="tv-search-filter"><span>'+title+'</span><select id="'+id+'" class="tv-search-control">'+options.map(v=>'<option value="'+esc(v[0])+'"'+(v[0]===selected?' selected':'')+'>'+esc(v[1])+'</option>').join('')+'</select></label>'}
 const kind=S.tvSearchKind||'الكل',dub=S.tvSearchDub||'الكل',country=S.tvSearchCountry||'الكل',genre=S.tvSearchGenre||'الكل',type=S.tvSearchType||'الكل';
 const opts=groups[kind]||Object.values(groups).flat();
 return '<aside class="tv-search-sidebar"><h2>الأقسام والأنواع والدول والمدبلج والمترجم والتصنيفات</h2>'+
 selection('tv-search-hub','القسم',types,kind)+
 selection('tv-search-type','نوع المحتوى',[['الكل','الكل'],...opts.flatMap(g=>g.rows)],type)+
 selection('tv-search-country','الدولة',countries.map(v=>[v,v]),country)+
 selection('tv-search-dub','الصوت',[['الكل','الكل'],['مدبلجة','مدبلجة'],['مترجمة','مترجمة']],dub)+
 selection('tv-search-genre','التصنيفات',genres.map(v=>[v,v]),genre)+
 '<button data-tv-search-reset class="action tv-search-reset">إعادة ضبط الفلاتر</button></aside>';
}
function searchFilter(rows){
 return rows.filter(x=>(!S.tvSearchKind||S.tvSearchKind==='الكل'||x.kind===S.tvSearchKind)&&
 (!S.tvSearchType||S.tvSearchType==='الكل'||match(x,S.tvSearchType))&&
 (!S.tvSearchDub||S.tvSearchDub==='الكل'||(S.tvSearchDub==='مدبلجة'===x.dubbed))&&
 (!S.tvSearchCountry||S.tvSearchCountry==='الكل'||String(x.country||'').includes(S.tvSearchCountry))&&
 (!S.tvSearchGenre||S.tvSearchGenre==='الكل'||(x.genres||[]).some(g=>String(g).includes(S.tvSearchGenre))));
}
return {groups,match,isRow,label,home,sourceCard,searchOptions,searchFilter};
})();